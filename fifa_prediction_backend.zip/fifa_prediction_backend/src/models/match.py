from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import db

class League(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    fifa_version = db.Column(db.String(50), nullable=False)  # ex: "FIFA FC 24", "FIFA FC 25"
    format = db.Column(db.String(50), nullable=False)  # ex: "4x4", "5x5", "3x3"
    region = db.Column(db.String(100), nullable=False)  # ex: "Angleterre", "Allemagne", "Espagne"
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'fifa_version': self.fifa_version,
            'format': self.format,
            'region': self.region
        }

class Team(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    league_id = db.Column(db.Integer, db.ForeignKey('league.id'), nullable=False)
    
    # Statistiques de l'équipe
    goals_scored_avg = db.Column(db.Float, default=0.0)
    goals_conceded_avg = db.Column(db.Float, default=0.0)
    wins = db.Column(db.Integer, default=0)
    draws = db.Column(db.Integer, default=0)
    losses = db.Column(db.Integer, default=0)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'league_id': self.league_id,
            'goals_scored_avg': self.goals_scored_avg,
            'goals_conceded_avg': self.goals_conceded_avg,
            'wins': self.wins,
            'draws': self.draws,
            'losses': self.losses
        }

class Match(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    home_team_id = db.Column(db.Integer, db.ForeignKey('team.id'), nullable=False)
    away_team_id = db.Column(db.Integer, db.ForeignKey('team.id'), nullable=False)
    league_id = db.Column(db.Integer, db.ForeignKey('league.id'), nullable=False)
    match_date = db.Column(db.DateTime, nullable=False)
    
    # Résultats réels (null si le match n'a pas encore eu lieu)
    home_goals_first_half = db.Column(db.Integer, nullable=True)
    away_goals_first_half = db.Column(db.Integer, nullable=True)
    home_goals_second_half = db.Column(db.Integer, nullable=True)
    away_goals_second_half = db.Column(db.Integer, nullable=True)
    home_goals_total = db.Column(db.Integer, nullable=True)
    away_goals_total = db.Column(db.Integer, nullable=True)
    
    # Relations
    home_team = db.relationship('Team', foreign_keys=[home_team_id], backref='home_matches')
    away_team = db.relationship('Team', foreign_keys=[away_team_id], backref='away_matches')
    league = db.relationship('League', backref='matches')
    
    def to_dict(self):
        return {
            'id': self.id,
            'home_team': self.home_team.to_dict() if self.home_team else None,
            'away_team': self.away_team.to_dict() if self.away_team else None,
            'league': self.league.to_dict() if self.league else None,
            'match_date': self.match_date.isoformat() if self.match_date else None,
            'home_goals_first_half': self.home_goals_first_half,
            'away_goals_first_half': self.away_goals_first_half,
            'home_goals_second_half': self.home_goals_second_half,
            'away_goals_second_half': self.away_goals_second_half,
            'home_goals_total': self.home_goals_total,
            'away_goals_total': self.away_goals_total
        }

class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    match_id = db.Column(db.Integer, db.ForeignKey('match.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Prédictions de résultat final (probabilités)
    home_win_prob = db.Column(db.Float, nullable=False)
    draw_prob = db.Column(db.Float, nullable=False)
    away_win_prob = db.Column(db.Float, nullable=False)
    
    # Prédictions première mi-temps (probabilités)
    home_win_ht_prob = db.Column(db.Float, nullable=False)
    draw_ht_prob = db.Column(db.Float, nullable=False)
    away_win_ht_prob = db.Column(db.Float, nullable=False)
    
    # Prédiction "les deux équipes marquent"
    both_teams_score_prob = db.Column(db.Float, nullable=False)
    
    # Prédictions de buts par mi-temps
    home_goals_first_half_pred = db.Column(db.Float, nullable=False)
    away_goals_first_half_pred = db.Column(db.Float, nullable=False)
    home_goals_second_half_pred = db.Column(db.Float, nullable=False)
    away_goals_second_half_pred = db.Column(db.Float, nullable=False)
    
    # Relation
    match = db.relationship('Match', backref='predictions')
    
    def to_dict(self):
        return {
            'id': self.id,
            'match_id': self.match_id,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'home_win_prob': self.home_win_prob,
            'draw_prob': self.draw_prob,
            'away_win_prob': self.away_win_prob,
            'home_win_ht_prob': self.home_win_ht_prob,
            'draw_ht_prob': self.draw_ht_prob,
            'away_win_ht_prob': self.away_win_ht_prob,
            'both_teams_score_prob': self.both_teams_score_prob,
            'home_goals_first_half_pred': self.home_goals_first_half_pred,
            'away_goals_first_half_pred': self.away_goals_first_half_pred,
            'home_goals_second_half_pred': self.home_goals_second_half_pred,
            'away_goals_second_half_pred': self.away_goals_second_half_pred
        }

