import numpy as np
import random
from datetime import datetime
from src.models.user import db
from scipy.stats import poisson

class PredictionService:
    """Service pour générer les prédictions de matchs FIFA virtuels"""
    
    def __init__(self):
        self.home_advantage = 0.1  # Avantage à domicile
        self.ml_service = None
        
    def _get_ml_service(self):
        """Initialise le service ML si nécessaire"""
        if self.ml_service is None:
            try:
                from src.services.ml_models import MLPredictionService
                self.ml_service = MLPredictionService()
            except ImportError as e:
                print(f"Impossible d'importer le service ML: {e}")
                self.ml_service = False
        return self.ml_service
        
    def generate_prediction(self, match):
        """Génère une prédiction complète pour un match"""
        try:
            from src.models.match import Match, Prediction, Team
            
            # Essayer d'abord avec les modèles ML
            ml_service = self._get_ml_service()
            if ml_service and ml_service is not False:
                ml_prediction = ml_service.predict_with_ml(match)
                if ml_prediction:
                    # Créer la prédiction avec les résultats ML
                    prediction = Prediction(
                        match_id=match.id,
                        **ml_prediction
                    )
                    
                    db.session.add(prediction)
                    db.session.commit()
                    return prediction
            
            # Fallback vers le modèle statistique traditionnel
            print("Utilisation du modèle statistique traditionnel")
            
            # Récupérer les statistiques des équipes
            home_team = match.home_team
            away_team = match.away_team
            
            # Calculer les prédictions de buts
            home_goals_pred, away_goals_pred = self._predict_goals(home_team, away_team)
            
            # Calculer les probabilités de résultat
            home_win_prob, draw_prob, away_win_prob = self._calculate_result_probabilities(
                home_goals_pred, away_goals_pred
            )
            
            # Calculer les prédictions pour la première mi-temps
            home_goals_ht_pred = home_goals_pred * 0.45  # Environ 45% des buts en première mi-temps
            away_goals_ht_pred = away_goals_pred * 0.45
            
            home_win_ht_prob, draw_ht_prob, away_win_ht_prob = self._calculate_result_probabilities(
                home_goals_ht_pred, away_goals_ht_pred
            )
            
            # Calculer la probabilité que les deux équipes marquent
            both_teams_score_prob = self._calculate_both_teams_score_probability(
                home_goals_pred, away_goals_pred
            )
            
            # Répartir les buts par mi-temps
            home_goals_first_half = home_goals_ht_pred
            away_goals_first_half = away_goals_ht_pred
            home_goals_second_half = home_goals_pred - home_goals_ht_pred
            away_goals_second_half = away_goals_pred - away_goals_ht_pred
            
            # Créer la prédiction
            prediction = Prediction(
                match_id=match.id,
                home_win_prob=home_win_prob,
                draw_prob=draw_prob,
                away_win_prob=away_win_prob,
                home_win_ht_prob=home_win_ht_prob,
                draw_ht_prob=draw_ht_prob,
                away_win_ht_prob=away_win_ht_prob,
                both_teams_score_prob=both_teams_score_prob,
                home_goals_first_half_pred=home_goals_first_half,
                away_goals_first_half_pred=away_goals_first_half,
                home_goals_second_half_pred=home_goals_second_half,
                away_goals_second_half_pred=away_goals_second_half
            )
            
            db.session.add(prediction)
            db.session.commit()
            
            return prediction
            
        except Exception as e:
            print(f"Erreur lors de la génération de prédiction: {e}")
            db.session.rollback()
            return None
    
    def _predict_goals(self, home_team, away_team):
        """Prédit le nombre de buts pour chaque équipe"""
        # Utiliser les moyennes de buts avec ajustement pour l'avantage à domicile
        home_attack_strength = home_team.goals_scored_avg * (1 + self.home_advantage)
        home_defense_strength = home_team.goals_conceded_avg
        
        away_attack_strength = away_team.goals_scored_avg
        away_defense_strength = away_team.goals_conceded_avg * (1 + self.home_advantage)
        
        # Calculer les buts attendus en tenant compte de l'attaque et de la défense
        home_goals_expected = (home_attack_strength + away_defense_strength) / 2
        away_goals_expected = (away_attack_strength + home_defense_strength) / 2
        
        # Ajouter un peu de randomness basé sur la forme récente
        home_form_factor = self._calculate_form_factor(home_team)
        away_form_factor = self._calculate_form_factor(away_team)
        
        home_goals_pred = max(0, home_goals_expected * home_form_factor)
        away_goals_pred = max(0, away_goals_expected * away_form_factor)
        
        return home_goals_pred, away_goals_pred
    
    def _calculate_form_factor(self, team):
        """Calcule un facteur de forme basé sur les résultats récents"""
        total_matches = team.wins + team.draws + team.losses
        if total_matches == 0:
            return 1.0
        
        # Calculer le pourcentage de victoires et nuls
        win_rate = team.wins / total_matches
        draw_rate = team.draws / total_matches
        
        # Facteur de forme entre 0.8 et 1.2
        form_factor = 0.8 + 0.4 * (win_rate + 0.5 * draw_rate)
        return form_factor
    
    def _calculate_result_probabilities(self, home_goals, away_goals):
        """Calcule les probabilités de victoire, nul, défaite"""
        # Utiliser la distribution de Poisson pour calculer les probabilités
        max_goals = 6  # Limite raisonnable pour les calculs
        
        home_win_prob = 0.0
        draw_prob = 0.0
        away_win_prob = 0.0
        
        for h in range(max_goals + 1):
            for a in range(max_goals + 1):
                prob_h = poisson.pmf(h, home_goals)
                prob_a = poisson.pmf(a, away_goals)
                prob_score = prob_h * prob_a
                
                if h > a:
                    home_win_prob += prob_score
                elif h == a:
                    draw_prob += prob_score
                else:
                    away_win_prob += prob_score
        
        # Normaliser pour s'assurer que la somme = 1
        total = home_win_prob + draw_prob + away_win_prob
        if total > 0:
            home_win_prob /= total
            draw_prob /= total
            away_win_prob /= total
        
        return home_win_prob, draw_prob, away_win_prob
    
    def _calculate_both_teams_score_probability(self, home_goals, away_goals):
        """Calcule la probabilité que les deux équipes marquent"""
        # Probabilité qu'aucune équipe ne marque
        prob_home_no_goals = poisson.pmf(0, home_goals)
        prob_away_no_goals = poisson.pmf(0, away_goals)
        
        # Probabilité que les deux équipes marquent = 1 - P(au moins une équipe ne marque pas)
        prob_both_score = 1 - (prob_home_no_goals + prob_away_no_goals - prob_home_no_goals * prob_away_no_goals)
        
        return max(0, min(1, prob_both_score))
    
    def generate_sample_data(self):
        """Génère des données d'exemple pour tester l'application"""
        try:
            from src.models.match import League, Team, Match, Prediction
            
            # Créer les ligues
            leagues_data = [
                {"name": "FIFA FC 24. 4x4 Championnat d'Angleterre", "fifa_version": "FIFA FC 24", "format": "4x4", "region": "Angleterre"},
                {"name": "FIFA FC 24.5x5 Super ligue", "fifa_version": "FIFA FC 24", "format": "5x5", "region": "International"},
                {"name": "FIFA F24. Ligue européenne", "fifa_version": "FIFA FC 24", "format": "11x11", "region": "Europe"},
                {"name": "FIFA FC 24.Championnat d'Allemagne", "fifa_version": "FIFA FC 24", "format": "11x11", "region": "Allemagne"},
                {"name": "FIFA FC 24.Championnat d'Espagne", "fifa_version": "FIFA FC 24", "format": "11x11", "region": "Espagne"},
                {"name": "FIFA FC 25.3x3 ligue de conférence", "fifa_version": "FIFA FC 25", "format": "3x3", "region": "International"},
                {"name": "FIFA FC 25. Champion league", "fifa_version": "FIFA FC 25", "format": "11x11", "region": "Europe"}
            ]
            
            leagues = []
            for league_data in leagues_data:
                league = League.query.filter_by(name=league_data["name"]).first()
                if not league:
                    league = League(**league_data)
                    db.session.add(league)
                leagues.append(league)
            
            db.session.commit()
            
            # Créer des équipes pour chaque ligue
            team_names = [
                "Arsenal Virtual", "Chelsea Digital", "Manchester United FC", "Liverpool FC",
                "Real Madrid Virtual", "Barcelona Digital", "Bayern Munich", "Juventus FC",
                "PSG Virtual", "AC Milan", "Inter Milan", "Atletico Madrid",
                "Borussia Dortmund", "Manchester City", "Tottenham", "Leicester City"
            ]
            
            teams = []
            for league in leagues:
                for i in range(8):  # 8 équipes par ligue
                    team_name = f"{team_names[i % len(team_names)]} ({league.region})"
                    team = Team.query.filter_by(name=team_name, league_id=league.id).first()
                    if not team:
                        team = Team(
                            name=team_name,
                            league_id=league.id,
                            goals_scored_avg=random.uniform(1.0, 3.0),
                            goals_conceded_avg=random.uniform(0.5, 2.5),
                            wins=random.randint(5, 15),
                            draws=random.randint(2, 8),
                            losses=random.randint(2, 10)
                        )
                        db.session.add(team)
                    teams.append(team)
            
            db.session.commit()
            
            # Créer des matchs pour les prochains jours
            from datetime import datetime, timedelta
            
            for i in range(20):  # 20 matchs d'exemple
                match_date = datetime.utcnow() + timedelta(hours=random.randint(1, 168))  # Dans les 7 prochains jours
                
                # Sélectionner deux équipes de la même ligue
                league = random.choice(leagues)
                league_teams = [t for t in teams if t.league_id == league.id]
                
                if len(league_teams) >= 2:
                    home_team, away_team = random.sample(league_teams, 2)
                    
                    # Vérifier qu'un match similaire n'existe pas déjà
                    existing_match = Match.query.filter_by(
                        home_team_id=home_team.id,
                        away_team_id=away_team.id,
                        league_id=league.id
                    ).filter(Match.match_date >= datetime.utcnow()).first()
                    
                    if not existing_match:
                        match = Match(
                            home_team_id=home_team.id,
                            away_team_id=away_team.id,
                            league_id=league.id,
                            match_date=match_date
                        )
                        db.session.add(match)
            
            db.session.commit()
            print("Données d'exemple générées avec succès!")
            
        except Exception as e:
            print(f"Erreur lors de la génération des données d'exemple: {e}")
            db.session.rollback()

