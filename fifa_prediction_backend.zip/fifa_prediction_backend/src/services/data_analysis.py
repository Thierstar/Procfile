import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from src.models.user import db
from src.models.match import Match, Team, League, Prediction

class DataAnalysisService:
    """Service pour l'analyse statistique des données de matchs"""
    
    def __init__(self):
        pass
    
    def get_team_statistics(self, team_id, days_back=30):
        """Récupère les statistiques d'une équipe sur les derniers jours"""
        from src.models.match import Match, Team
        
        cutoff_date = datetime.utcnow() - timedelta(days=days_back)
        
        # Matchs à domicile
        home_matches = Match.query.filter(
            Match.home_team_id == team_id,
            Match.match_date >= cutoff_date,
            Match.home_goals_total.isnot(None)  # Matchs terminés
        ).all()
        
        # Matchs à l'extérieur
        away_matches = Match.query.filter(
            Match.away_team_id == team_id,
            Match.match_date >= cutoff_date,
            Match.away_goals_total.isnot(None)  # Matchs terminés
        ).all()
        
        stats = {
            'matches_played': len(home_matches) + len(away_matches),
            'home_matches': len(home_matches),
            'away_matches': len(away_matches),
            'goals_scored': 0,
            'goals_conceded': 0,
            'wins': 0,
            'draws': 0,
            'losses': 0,
            'goals_scored_home': 0,
            'goals_conceded_home': 0,
            'goals_scored_away': 0,
            'goals_conceded_away': 0,
            'first_half_goals_scored': 0,
            'first_half_goals_conceded': 0,
            'second_half_goals_scored': 0,
            'second_half_goals_conceded': 0
        }
        
        # Analyser les matchs à domicile
        for match in home_matches:
            goals_for = match.home_goals_total
            goals_against = match.away_goals_total
            
            stats['goals_scored'] += goals_for
            stats['goals_conceded'] += goals_against
            stats['goals_scored_home'] += goals_for
            stats['goals_conceded_home'] += goals_against
            
            if match.home_goals_first_half is not None:
                stats['first_half_goals_scored'] += match.home_goals_first_half
                stats['second_half_goals_scored'] += match.home_goals_second_half
            
            if match.away_goals_first_half is not None:
                stats['first_half_goals_conceded'] += match.away_goals_first_half
                stats['second_half_goals_conceded'] += match.away_goals_second_half
            
            if goals_for > goals_against:
                stats['wins'] += 1
            elif goals_for == goals_against:
                stats['draws'] += 1
            else:
                stats['losses'] += 1
        
        # Analyser les matchs à l'extérieur
        for match in away_matches:
            goals_for = match.away_goals_total
            goals_against = match.home_goals_total
            
            stats['goals_scored'] += goals_for
            stats['goals_conceded'] += goals_against
            stats['goals_scored_away'] += goals_for
            stats['goals_conceded_away'] += goals_against
            
            if match.away_goals_first_half is not None:
                stats['first_half_goals_scored'] += match.away_goals_first_half
                stats['second_half_goals_scored'] += match.away_goals_second_half
            
            if match.home_goals_first_half is not None:
                stats['first_half_goals_conceded'] += match.home_goals_first_half
                stats['second_half_goals_conceded'] += match.home_goals_second_half
            
            if goals_for > goals_against:
                stats['wins'] += 1
            elif goals_for == goals_against:
                stats['draws'] += 1
            else:
                stats['losses'] += 1
        
        # Calculer les moyennes
        if stats['matches_played'] > 0:
            stats['avg_goals_scored'] = stats['goals_scored'] / stats['matches_played']
            stats['avg_goals_conceded'] = stats['goals_conceded'] / stats['matches_played']
            stats['win_rate'] = stats['wins'] / stats['matches_played']
            stats['draw_rate'] = stats['draws'] / stats['matches_played']
            stats['loss_rate'] = stats['losses'] / stats['matches_played']
        else:
            stats['avg_goals_scored'] = 0
            stats['avg_goals_conceded'] = 0
            stats['win_rate'] = 0
            stats['draw_rate'] = 0
            stats['loss_rate'] = 0
        
        return stats
    
    def get_head_to_head_stats(self, team1_id, team2_id, matches_limit=10):
        """Récupère les statistiques des confrontations directes entre deux équipes"""
        from src.models.match import Match
        
        # Matchs où team1 joue à domicile contre team2
        matches_1_home = Match.query.filter(
            Match.home_team_id == team1_id,
            Match.away_team_id == team2_id,
            Match.home_goals_total.isnot(None)
        ).order_by(Match.match_date.desc()).limit(matches_limit // 2).all()
        
        # Matchs où team2 joue à domicile contre team1
        matches_2_home = Match.query.filter(
            Match.home_team_id == team2_id,
            Match.away_team_id == team1_id,
            Match.home_goals_total.isnot(None)
        ).order_by(Match.match_date.desc()).limit(matches_limit // 2).all()
        
        all_matches = matches_1_home + matches_2_home
        all_matches.sort(key=lambda x: x.match_date, reverse=True)
        
        stats = {
            'total_matches': len(all_matches),
            'team1_wins': 0,
            'team2_wins': 0,
            'draws': 0,
            'team1_goals': 0,
            'team2_goals': 0,
            'avg_goals_per_match': 0,
            'both_teams_scored_count': 0
        }
        
        for match in all_matches:
            if match.home_team_id == team1_id:
                # team1 à domicile
                team1_goals = match.home_goals_total
                team2_goals = match.away_goals_total
            else:
                # team2 à domicile
                team1_goals = match.away_goals_total
                team2_goals = match.home_goals_total
            
            stats['team1_goals'] += team1_goals
            stats['team2_goals'] += team2_goals
            
            if team1_goals > 0 and team2_goals > 0:
                stats['both_teams_scored_count'] += 1
            
            if team1_goals > team2_goals:
                stats['team1_wins'] += 1
            elif team2_goals > team1_goals:
                stats['team2_wins'] += 1
            else:
                stats['draws'] += 1
        
        if stats['total_matches'] > 0:
            total_goals = stats['team1_goals'] + stats['team2_goals']
            stats['avg_goals_per_match'] = total_goals / stats['total_matches']
            stats['both_teams_scored_rate'] = stats['both_teams_scored_count'] / stats['total_matches']
            stats['team1_win_rate'] = stats['team1_wins'] / stats['total_matches']
            stats['team2_win_rate'] = stats['team2_wins'] / stats['total_matches']
            stats['draw_rate'] = stats['draws'] / stats['total_matches']
        else:
            stats['both_teams_scored_rate'] = 0
            stats['team1_win_rate'] = 0
            stats['team2_win_rate'] = 0
            stats['draw_rate'] = 0
        
        return stats
    
    def calculate_league_averages(self, league_id):
        """Calcule les moyennes de la ligue pour contextualiser les performances"""
        from src.models.match import Match
        
        matches = Match.query.filter(
            Match.league_id == league_id,
            Match.home_goals_total.isnot(None)
        ).all()
        
        if not matches:
            return {
                'avg_goals_per_match': 2.5,
                'avg_home_goals': 1.4,
                'avg_away_goals': 1.1,
                'home_win_rate': 0.45,
                'draw_rate': 0.25,
                'away_win_rate': 0.30
            }
        
        total_goals = 0
        home_goals = 0
        away_goals = 0
        home_wins = 0
        draws = 0
        away_wins = 0
        
        for match in matches:
            home_score = match.home_goals_total
            away_score = match.away_goals_total
            
            total_goals += home_score + away_score
            home_goals += home_score
            away_goals += away_score
            
            if home_score > away_score:
                home_wins += 1
            elif home_score == away_score:
                draws += 1
            else:
                away_wins += 1
        
        total_matches = len(matches)
        
        return {
            'avg_goals_per_match': total_goals / total_matches,
            'avg_home_goals': home_goals / total_matches,
            'avg_away_goals': away_goals / total_matches,
            'home_win_rate': home_wins / total_matches,
            'draw_rate': draws / total_matches,
            'away_win_rate': away_wins / total_matches
        }
    
    def evaluate_prediction_accuracy(self, days_back=7):
        """Évalue la précision des prédictions récentes"""
        from src.models.match import Match, Prediction
        
        cutoff_date = datetime.utcnow() - timedelta(days=days_back)
        
        # Récupérer les prédictions avec leurs matchs terminés
        predictions_with_results = db.session.query(Prediction, Match).join(Match).filter(
            Prediction.created_at >= cutoff_date,
            Match.home_goals_total.isnot(None)  # Match terminé
        ).all()
        
        if not predictions_with_results:
            return {
                'total_predictions': 0,
                'correct_results': 0,
                'accuracy': 0,
                'avg_probability_error': 0
            }
        
        correct_results = 0
        total_probability_error = 0
        
        for prediction, match in predictions_with_results:
            # Déterminer le résultat réel
            if match.home_goals_total > match.away_goals_total:
                actual_result = 'home_win'
            elif match.home_goals_total == match.away_goals_total:
                actual_result = 'draw'
            else:
                actual_result = 'away_win'
            
            # Déterminer la prédiction (résultat avec la plus haute probabilité)
            probs = {
                'home_win': prediction.home_win_prob,
                'draw': prediction.draw_prob,
                'away_win': prediction.away_win_prob
            }
            predicted_result = max(probs, key=probs.get)
            
            if predicted_result == actual_result:
                correct_results += 1
            
            # Calculer l'erreur de probabilité
            actual_prob = probs[actual_result]
            total_probability_error += abs(1.0 - actual_prob)
        
        total_predictions = len(predictions_with_results)
        
        return {
            'total_predictions': total_predictions,
            'correct_results': correct_results,
            'accuracy': correct_results / total_predictions,
            'avg_probability_error': total_probability_error / total_predictions
        }

