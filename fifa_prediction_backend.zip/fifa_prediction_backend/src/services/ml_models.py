import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LogisticRegression, PoissonRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, mean_squared_error
import joblib
import os
from datetime import datetime, timedelta
from src.models.user import db
from src.services.data_analysis import DataAnalysisService

class MLPredictionService:
    """Service de prédiction utilisant des modèles de machine learning"""
    
    def __init__(self):
        self.models = {}
        self.scalers = {}
        self.data_analysis = DataAnalysisService()
        self.models_dir = os.path.join(os.path.dirname(__file__), '..', 'models_ml')
        os.makedirs(self.models_dir, exist_ok=True)
    
    def prepare_features(self, home_team_id, away_team_id, league_id):
        """Prépare les caractéristiques pour la prédiction"""
        from src.models.match import Team, League
        
        # Statistiques des équipes
        home_stats = self.data_analysis.get_team_statistics(home_team_id)
        away_stats = self.data_analysis.get_team_statistics(away_team_id)
        h2h_stats = self.data_analysis.get_head_to_head_stats(home_team_id, away_team_id)
        league_averages = self.data_analysis.calculate_league_averages(league_id)
        
        # Créer le vecteur de caractéristiques
        features = [
            # Statistiques équipe domicile
            home_stats['avg_goals_scored'],
            home_stats['avg_goals_conceded'],
            home_stats['win_rate'],
            home_stats['draw_rate'],
            home_stats['goals_scored_home'] / max(home_stats['home_matches'], 1),
            home_stats['goals_conceded_home'] / max(home_stats['home_matches'], 1),
            
            # Statistiques équipe extérieur
            away_stats['avg_goals_scored'],
            away_stats['avg_goals_conceded'],
            away_stats['win_rate'],
            away_stats['draw_rate'],
            away_stats['goals_scored_away'] / max(away_stats['away_matches'], 1),
            away_stats['goals_conceded_away'] / max(away_stats['away_matches'], 1),
            
            # Confrontations directes
            h2h_stats['team1_win_rate'],
            h2h_stats['draw_rate'],
            h2h_stats['team2_win_rate'],
            h2h_stats['avg_goals_per_match'],
            h2h_stats['both_teams_scored_rate'],
            
            # Moyennes de la ligue
            league_averages['avg_goals_per_match'],
            league_averages['home_win_rate'],
            league_averages['draw_rate'],
            league_averages['away_win_rate'],
            
            # Différentiels
            home_stats['avg_goals_scored'] - away_stats['avg_goals_conceded'],
            away_stats['avg_goals_scored'] - home_stats['avg_goals_conceded'],
            home_stats['win_rate'] - away_stats['win_rate']
        ]
        
        return np.array(features).reshape(1, -1)
    
    def collect_training_data(self, min_matches=50):
        """Collecte les données d'entraînement à partir de la base de données"""
        from src.models.match import Match, Team, League
        
        # Récupérer tous les matchs terminés
        matches = Match.query.filter(
            Match.home_goals_total.isnot(None)
        ).all()
        
        if len(matches) < min_matches:
            print(f"Pas assez de données d'entraînement ({len(matches)} matchs, minimum {min_matches})")
            return None, None
        
        features_list = []
        labels_result = []
        labels_home_goals = []
        labels_away_goals = []
        labels_both_score = []
        
        for match in matches:
            try:
                # Préparer les caractéristiques
                features = self.prepare_features(
                    match.home_team_id, 
                    match.away_team_id, 
                    match.league_id
                ).flatten()
                
                # Préparer les labels
                if match.home_goals_total > match.away_goals_total:
                    result_label = 0  # Victoire domicile
                elif match.home_goals_total == match.away_goals_total:
                    result_label = 1  # Match nul
                else:
                    result_label = 2  # Victoire extérieur
                
                both_score_label = 1 if (match.home_goals_total > 0 and match.away_goals_total > 0) else 0
                
                features_list.append(features)
                labels_result.append(result_label)
                labels_home_goals.append(match.home_goals_total)
                labels_away_goals.append(match.away_goals_total)
                labels_both_score.append(both_score_label)
                
            except Exception as e:
                print(f"Erreur lors du traitement du match {match.id}: {e}")
                continue
        
        if len(features_list) == 0:
            return None, None
        
        X = np.array(features_list)
        y = {
            'result': np.array(labels_result),
            'home_goals': np.array(labels_home_goals),
            'away_goals': np.array(labels_away_goals),
            'both_score': np.array(labels_both_score)
        }
        
        return X, y
    
    def train_models(self):
        """Entraîne tous les modèles de machine learning"""
        print("Collecte des données d'entraînement...")
        X, y = self.collect_training_data()
        
        if X is None or y is None:
            print("Impossible de collecter les données d'entraînement")
            return False
        
        print(f"Entraînement avec {X.shape[0]} échantillons et {X.shape[1]} caractéristiques")
        
        # Normalisation des caractéristiques
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        self.scalers['main'] = scaler
        
        # Division train/test
        X_train, X_test, y_train_result, y_test_result = train_test_split(
            X_scaled, y['result'], test_size=0.2, random_state=42
        )
        
        # 1. Modèle de prédiction de résultat (1X2)
        print("Entraînement du modèle de résultat...")
        result_model = RandomForestClassifier(n_estimators=100, random_state=42)
        result_model.fit(X_train, y_train_result)
        
        # Évaluation
        y_pred_result = result_model.predict(X_test)
        accuracy = accuracy_score(y_test_result, y_pred_result)
        print(f"Précision du modèle de résultat: {accuracy:.3f}")
        
        self.models['result'] = result_model
        
        # 2. Modèle de prédiction de buts domicile
        print("Entraînement du modèle de buts domicile...")
        _, _, y_train_home, y_test_home = train_test_split(
            X_scaled, y['home_goals'], test_size=0.2, random_state=42
        )
        
        home_goals_model = PoissonRegressor(alpha=1.0)
        home_goals_model.fit(X_train, y_train_home)
        
        y_pred_home = home_goals_model.predict(X_test)
        mse_home = mean_squared_error(y_test_home, y_pred_home)
        print(f"MSE du modèle de buts domicile: {mse_home:.3f}")
        
        self.models['home_goals'] = home_goals_model
        
        # 3. Modèle de prédiction de buts extérieur
        print("Entraînement du modèle de buts extérieur...")
        _, _, y_train_away, y_test_away = train_test_split(
            X_scaled, y['away_goals'], test_size=0.2, random_state=42
        )
        
        away_goals_model = PoissonRegressor(alpha=1.0)
        away_goals_model.fit(X_train, y_train_away)
        
        y_pred_away = away_goals_model.predict(X_test)
        mse_away = mean_squared_error(y_test_away, y_pred_away)
        print(f"MSE du modèle de buts extérieur: {mse_away:.3f}")
        
        self.models['away_goals'] = away_goals_model
        
        # 4. Modèle "les deux équipes marquent"
        print("Entraînement du modèle 'les deux équipes marquent'...")
        _, _, y_train_both, y_test_both = train_test_split(
            X_scaled, y['both_score'], test_size=0.2, random_state=42
        )
        
        both_score_model = LogisticRegression(random_state=42)
        both_score_model.fit(X_train, y_train_both)
        
        y_pred_both = both_score_model.predict(X_test)
        accuracy_both = accuracy_score(y_test_both, y_pred_both)
        print(f"Précision du modèle 'les deux équipes marquent': {accuracy_both:.3f}")
        
        self.models['both_score'] = both_score_model
        
        # Sauvegarder les modèles
        self.save_models()
        
        print("Entraînement terminé avec succès!")
        return True
    
    def save_models(self):
        """Sauvegarde les modèles entraînés"""
        for name, model in self.models.items():
            model_path = os.path.join(self.models_dir, f'{name}_model.pkl')
            joblib.dump(model, model_path)
        
        for name, scaler in self.scalers.items():
            scaler_path = os.path.join(self.models_dir, f'{name}_scaler.pkl')
            joblib.dump(scaler, scaler_path)
        
        print(f"Modèles sauvegardés dans {self.models_dir}")
    
    def load_models(self):
        """Charge les modèles sauvegardés"""
        model_names = ['result', 'home_goals', 'away_goals', 'both_score']
        
        for name in model_names:
            model_path = os.path.join(self.models_dir, f'{name}_model.pkl')
            if os.path.exists(model_path):
                self.models[name] = joblib.load(model_path)
            else:
                print(f"Modèle {name} non trouvé, utilisation du modèle statistique par défaut")
                return False
        
        scaler_path = os.path.join(self.models_dir, 'main_scaler.pkl')
        if os.path.exists(scaler_path):
            self.scalers['main'] = joblib.load(scaler_path)
        else:
            print("Scaler non trouvé")
            return False
        
        print("Modèles chargés avec succès!")
        return True
    
    def predict_with_ml(self, match):
        """Génère une prédiction en utilisant les modèles ML"""
        if not self.models or not self.scalers:
            if not self.load_models():
                print("Impossible de charger les modèles ML, utilisation du modèle statistique")
                return None
        
        try:
            # Préparer les caractéristiques
            features = self.prepare_features(
                match.home_team_id,
                match.away_team_id,
                match.league_id
            )
            
            # Normaliser
            features_scaled = self.scalers['main'].transform(features)
            
            # Prédictions
            result_probs = self.models['result'].predict_proba(features_scaled)[0]
            home_goals_pred = max(0, self.models['home_goals'].predict(features_scaled)[0])
            away_goals_pred = max(0, self.models['away_goals'].predict(features_scaled)[0])
            both_score_prob = self.models['both_score'].predict_proba(features_scaled)[0][1]
            
            # Calculer les prédictions pour les mi-temps (approximation)
            home_goals_ht = home_goals_pred * 0.45
            away_goals_ht = away_goals_pred * 0.45
            
            # Prédictions mi-temps basées sur les buts totaux
            if home_goals_ht > away_goals_ht:
                ht_home_prob = 0.6
                ht_draw_prob = 0.25
                ht_away_prob = 0.15
            elif home_goals_ht == away_goals_ht:
                ht_home_prob = 0.3
                ht_draw_prob = 0.4
                ht_away_prob = 0.3
            else:
                ht_home_prob = 0.15
                ht_draw_prob = 0.25
                ht_away_prob = 0.6
            
            return {
                'home_win_prob': float(result_probs[0]),
                'draw_prob': float(result_probs[1]),
                'away_win_prob': float(result_probs[2]),
                'home_win_ht_prob': ht_home_prob,
                'draw_ht_prob': ht_draw_prob,
                'away_win_ht_prob': ht_away_prob,
                'both_teams_score_prob': float(both_score_prob),
                'home_goals_first_half_pred': float(home_goals_ht),
                'away_goals_first_half_pred': float(away_goals_ht),
                'home_goals_second_half_pred': float(home_goals_pred - home_goals_ht),
                'away_goals_second_half_pred': float(away_goals_pred - away_goals_ht)
            }
            
        except Exception as e:
            print(f"Erreur lors de la prédiction ML: {e}")
            return None

