from flask import Blueprint, jsonify, request
from src.models.match import Match, Prediction, League, Team, db
from src.services.prediction_service import PredictionService
from datetime import datetime, timedelta

prediction_bp = Blueprint('prediction', __name__)

@prediction_bp.route('/leagues', methods=['GET'])
def get_leagues():
    """Récupère toutes les ligues disponibles"""
    leagues = League.query.all()
    return jsonify([league.to_dict() for league in leagues])

@prediction_bp.route('/matches', methods=['GET'])
def get_matches():
    """Récupère les matchs avec filtres optionnels"""
    league_id = request.args.get('league_id', type=int)
    days_ahead = request.args.get('days_ahead', default=7, type=int)
    
    # Filtrer les matchs des prochains jours
    start_date = datetime.utcnow()
    end_date = start_date + timedelta(days=days_ahead)
    
    query = Match.query.filter(Match.match_date >= start_date, Match.match_date <= end_date)
    
    if league_id:
        query = query.filter(Match.league_id == league_id)
    
    matches = query.order_by(Match.match_date).all()
    return jsonify([match.to_dict() for match in matches])

@prediction_bp.route('/matches/<int:match_id>/prediction', methods=['GET'])
def get_match_prediction(match_id):
    """Récupère la prédiction pour un match spécifique"""
    match = Match.query.get_or_404(match_id)
    
    # Chercher la prédiction la plus récente pour ce match
    prediction = Prediction.query.filter_by(match_id=match_id).order_by(Prediction.created_at.desc()).first()
    
    if not prediction:
        # Générer une nouvelle prédiction si elle n'existe pas
        prediction_service = PredictionService()
        prediction = prediction_service.generate_prediction(match)
    
    result = {
        'match': match.to_dict(),
        'prediction': prediction.to_dict() if prediction else None
    }
    
    return jsonify(result)

@prediction_bp.route('/matches/<int:match_id>/prediction', methods=['POST'])
def generate_prediction(match_id):
    """Force la génération d'une nouvelle prédiction pour un match"""
    match = Match.query.get_or_404(match_id)
    
    prediction_service = PredictionService()
    prediction = prediction_service.generate_prediction(match)
    
    if prediction:
        return jsonify(prediction.to_dict()), 201
    else:
        return jsonify({'error': 'Impossible de générer une prédiction'}), 500

@prediction_bp.route('/predictions/recent', methods=['GET'])
def get_recent_predictions():
    """Récupère les prédictions récentes avec leurs résultats"""
    days_back = request.args.get('days_back', default=7, type=int)
    
    start_date = datetime.utcnow() - timedelta(days=days_back)
    
    predictions = db.session.query(Prediction, Match).join(Match).filter(
        Prediction.created_at >= start_date
    ).order_by(Prediction.created_at.desc()).all()
    
    result = []
    for prediction, match in predictions:
        result.append({
            'prediction': prediction.to_dict(),
            'match': match.to_dict()
        })
    
    return jsonify(result)

