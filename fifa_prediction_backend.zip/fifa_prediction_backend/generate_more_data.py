#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from src.main import app
import random
from datetime import datetime, timedelta

def generate_extensive_data():
    """Génère beaucoup plus de données pour l'entraînement"""
    with app.app_context():
        from src.models.match import League, Team, Match
        from src.models.user import db
        
        print("Génération de données étendues...")
        
        leagues = League.query.all()
        
        # Générer plus de matchs historiques
        for league in leagues:
            teams = Team.query.filter_by(league_id=league.id).all()
            
            if len(teams) < 2:
                continue
            
            print(f"Génération de matchs pour {league.name}...")
            
            # Générer 50 matchs par ligue (350 matchs au total)
            for i in range(50):
                # Sélectionner deux équipes différentes
                home_team, away_team = random.sample(teams, 2)
                
                # Date dans le passé (derniers 6 mois)
                match_date = datetime.utcnow() - timedelta(days=random.randint(1, 180))
                
                # Générer des résultats réalistes basés sur les statistiques des équipes
                home_strength = home_team.goals_scored_avg / max(home_team.goals_conceded_avg, 0.5)
                away_strength = away_team.goals_scored_avg / max(away_team.goals_conceded_avg, 0.5)
                
                # Ajuster pour l'avantage à domicile
                home_strength *= 1.2
                
                # Calculer les buts attendus
                total_strength = home_strength + away_strength
                if total_strength > 0:
                    home_goal_prob = home_strength / total_strength
                else:
                    home_goal_prob = 0.5
                
                # Générer les buts
                total_goals = random.choices([0, 1, 2, 3, 4, 5, 6], weights=[5, 15, 25, 25, 15, 10, 5])[0]
                
                if total_goals == 0:
                    home_goals = 0
                    away_goals = 0
                else:
                    home_goals = 0
                    away_goals = 0
                    for _ in range(total_goals):
                        if random.random() < home_goal_prob:
                            home_goals += 1
                        else:
                            away_goals += 1
                
                # Répartir par mi-temps
                home_first_half = 0
                away_first_half = 0
                
                # Environ 45% des buts en première mi-temps
                for _ in range(home_goals):
                    if random.random() < 0.45:
                        home_first_half += 1
                
                for _ in range(away_goals):
                    if random.random() < 0.45:
                        away_first_half += 1
                
                home_second_half = home_goals - home_first_half
                away_second_half = away_goals - away_first_half
                
                # Créer le match
                match = Match(
                    home_team_id=home_team.id,
                    away_team_id=away_team.id,
                    league_id=league.id,
                    match_date=match_date,
                    home_goals_total=home_goals,
                    away_goals_total=away_goals,
                    home_goals_first_half=home_first_half,
                    home_goals_second_half=home_second_half,
                    away_goals_first_half=away_first_half,
                    away_goals_second_half=away_second_half
                )
                
                db.session.add(match)
        
        # Mettre à jour les statistiques des équipes basées sur les nouveaux matchs
        for team in Team.query.all():
            home_matches = Match.query.filter_by(home_team_id=team.id).filter(Match.home_goals_total.isnot(None)).all()
            away_matches = Match.query.filter_by(away_team_id=team.id).filter(Match.away_goals_total.isnot(None)).all()
            
            total_goals_scored = 0
            total_goals_conceded = 0
            wins = 0
            draws = 0
            losses = 0
            
            for match in home_matches:
                total_goals_scored += match.home_goals_total
                total_goals_conceded += match.away_goals_total
                
                if match.home_goals_total > match.away_goals_total:
                    wins += 1
                elif match.home_goals_total == match.away_goals_total:
                    draws += 1
                else:
                    losses += 1
            
            for match in away_matches:
                total_goals_scored += match.away_goals_total
                total_goals_conceded += match.home_goals_total
                
                if match.away_goals_total > match.home_goals_total:
                    wins += 1
                elif match.away_goals_total == match.home_goals_total:
                    draws += 1
                else:
                    losses += 1
            
            total_matches = len(home_matches) + len(away_matches)
            
            if total_matches > 0:
                team.goals_scored_avg = total_goals_scored / total_matches
                team.goals_conceded_avg = total_goals_conceded / total_matches
                team.wins = wins
                team.draws = draws
                team.losses = losses
        
        db.session.commit()
        
        total_matches = Match.query.filter(Match.home_goals_total.isnot(None)).count()
        print(f"✅ Données générées avec succès! Total de {total_matches} matchs dans la base de données.")

if __name__ == '__main__':
    generate_extensive_data()

