#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from src.main import app
import random
from datetime import datetime, timedelta

def generate_future_matches():
    """Génère des matchs futurs pour l'application"""
    with app.app_context():
        from src.models.match import League, Team, Match
        from src.models.user import db
        
        print("Génération de matchs futurs...")
        
        leagues = League.query.all()
        
        # Supprimer les anciens matchs futurs
        Match.query.filter(Match.match_date > datetime.utcnow()).delete()
        
        # Générer des matchs pour les prochains jours
        for league in leagues:
            teams = Team.query.filter_by(league_id=league.id).all()
            
            if len(teams) < 2:
                continue
            
            print(f"Génération de matchs futurs pour {league.name}...")
            
            # Générer 5 matchs par ligue dans les prochains 7 jours
            for i in range(5):
                # Sélectionner deux équipes différentes
                home_team, away_team = random.sample(teams, 2)
                
                # Date dans le futur (prochains 7 jours)
                hours_ahead = random.randint(1, 168)  # 1 heure à 7 jours
                match_date = datetime.utcnow() + timedelta(hours=hours_ahead)
                
                # Créer le match (sans résultats car c'est dans le futur)
                match = Match(
                    home_team_id=home_team.id,
                    away_team_id=away_team.id,
                    league_id=league.id,
                    match_date=match_date
                )
                
                db.session.add(match)
        
        db.session.commit()
        
        total_future_matches = Match.query.filter(Match.match_date > datetime.utcnow()).count()
        print(f"✅ {total_future_matches} matchs futurs générés avec succès!")

if __name__ == '__main__':
    generate_future_matches()

