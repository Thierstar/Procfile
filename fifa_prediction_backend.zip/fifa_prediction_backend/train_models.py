#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from src.main import app
from src.services.ml_models import MLPredictionService
from src.services.prediction_service import PredictionService

def generate_more_sample_data():
    """Génère plus de données d'exemple pour l'entraînement"""
    with app.app_context():
        prediction_service = PredictionService()
        
        # Générer des résultats pour les matchs existants
        from src.models.match import Match
        import random
        
        matches = Match.query.filter(Match.home_goals_total.is_(None)).all()
        
        print(f"Génération de résultats pour {len(matches)} matchs...")
        
        for match in matches:
            # Simuler des résultats réalistes
            home_goals = random.choices([0, 1, 2, 3, 4], weights=[10, 30, 35, 20, 5])[0]
            away_goals = random.choices([0, 1, 2, 3, 4], weights=[15, 35, 30, 15, 5])[0]
            
            # Répartir les buts par mi-temps
            home_first_half = random.randint(0, home_goals)
            home_second_half = home_goals - home_first_half
            away_first_half = random.randint(0, away_goals)
            away_second_half = away_goals - away_first_half
            
            match.home_goals_total = home_goals
            match.away_goals_total = away_goals
            match.home_goals_first_half = home_first_half
            match.home_goals_second_half = home_second_half
            match.away_goals_first_half = away_first_half
            match.away_goals_second_half = away_second_half
        
        from src.models.user import db
        db.session.commit()
        print("Résultats générés avec succès!")

def train_ml_models():
    """Entraîne les modèles de machine learning"""
    with app.app_context():
        print("=== Entraînement des modèles ML ===")
        
        ml_service = MLPredictionService()
        success = ml_service.train_models()
        
        if success:
            print("✅ Modèles entraînés avec succès!")
        else:
            print("❌ Échec de l'entraînement des modèles")
        
        return success

def test_ml_predictions():
    """Teste les prédictions ML"""
    with app.app_context():
        print("\n=== Test des prédictions ML ===")
        
        from src.models.match import Match
        from src.services.prediction_service import PredictionService
        
        # Prendre un match d'exemple
        match = Match.query.filter(Match.home_goals_total.is_(None)).first()
        
        if not match:
            print("Aucun match disponible pour le test")
            return
        
        prediction_service = PredictionService()
        prediction = prediction_service.generate_prediction(match)
        
        if prediction:
            print(f"Match: {match.home_team.name} vs {match.away_team.name}")
            print(f"Probabilités de résultat final:")
            print(f"  - Victoire domicile: {prediction.home_win_prob:.2%}")
            print(f"  - Match nul: {prediction.draw_prob:.2%}")
            print(f"  - Victoire extérieur: {prediction.away_win_prob:.2%}")
            print(f"Les deux équipes marquent: {prediction.both_teams_score_prob:.2%}")
            print(f"Buts prédits:")
            print(f"  - Domicile 1ère mi-temps: {prediction.home_goals_first_half_pred:.1f}")
            print(f"  - Domicile 2ème mi-temps: {prediction.home_goals_second_half_pred:.1f}")
            print(f"  - Extérieur 1ère mi-temps: {prediction.away_goals_first_half_pred:.1f}")
            print(f"  - Extérieur 2ème mi-temps: {prediction.away_goals_second_half_pred:.1f}")
        else:
            print("Échec de la génération de prédiction")

if __name__ == '__main__':
    print("=== Entraînement des modèles FIFA Prediction ===")
    
    # Étape 1: Générer plus de données
    generate_more_sample_data()
    
    # Étape 2: Entraîner les modèles
    success = train_ml_models()
    
    if success:
        # Étape 3: Tester les prédictions
        test_ml_predictions()
    
    print("\n=== Terminé ===")

