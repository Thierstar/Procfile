#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from src.main import app
from src.models.match import League, Team, Match, Prediction
from src.services.prediction_service import PredictionService

def test_api():
    """Test les fonctionnalités de base de l'API"""
    with app.test_client() as client:
        print("=== Test de l'API FIFA Prediction Backend ===")
        
        # Test 1: Récupérer les ligues
        print("\n1. Test des ligues:")
        response = client.get('/api/leagues')
        print(f"Status: {response.status_code}")
        if response.status_code == 200:
            leagues = response.get_json()
            print(f"Nombre de ligues: {len(leagues)}")
            for league in leagues[:3]:  # Afficher les 3 premières
                print(f"  - {league['name']} ({league['fifa_version']})")
        else:
            print(f"Erreur: {response.data}")
        
        # Test 2: Récupérer les matchs
        print("\n2. Test des matchs:")
        response = client.get('/api/matches')
        print(f"Status: {response.status_code}")
        if response.status_code == 200:
            matches = response.get_json()
            print(f"Nombre de matchs: {len(matches)}")
            for match in matches[:3]:  # Afficher les 3 premiers
                home_team = match['home_team']['name'] if match['home_team'] else 'N/A'
                away_team = match['away_team']['name'] if match['away_team'] else 'N/A'
                print(f"  - {home_team} vs {away_team}")
        else:
            print(f"Erreur: {response.data}")
        
        # Test 3: Générer une prédiction
        if response.status_code == 200 and len(matches) > 0:
            print("\n3. Test de prédiction:")
            match_id = matches[0]['id']
            response = client.get(f'/api/matches/{match_id}/prediction')
            print(f"Status: {response.status_code}")
            if response.status_code == 200:
                prediction_data = response.get_json()
                prediction = prediction_data['prediction']
                match_info = prediction_data['match']
                
                print(f"Match: {match_info['home_team']['name']} vs {match_info['away_team']['name']}")
                print(f"Probabilités de résultat final:")
                print(f"  - Victoire domicile: {prediction['home_win_prob']:.2%}")
                print(f"  - Match nul: {prediction['draw_prob']:.2%}")
                print(f"  - Victoire extérieur: {prediction['away_win_prob']:.2%}")
                print(f"Les deux équipes marquent: {prediction['both_teams_score_prob']:.2%}")
            else:
                print(f"Erreur: {response.data}")
        
        print("\n=== Tests terminés ===")

if __name__ == '__main__':
    test_api()

