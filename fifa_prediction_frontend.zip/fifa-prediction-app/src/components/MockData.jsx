// Données de démonstration pour l'application FIFA Prediction
export const mockLeagues = [
  {
    id: 1,
    name: "FIFA FC 24. 4x4 Championnat d'Angleterre",
    fifa_version: "FIFA FC 24",
    format: "4x4",
    region: "Angleterre"
  },
  {
    id: 2,
    name: "FIFA FC 24.5x5 Super ligue",
    fifa_version: "FIFA FC 24", 
    format: "5x5",
    region: "International"
  },
  {
    id: 3,
    name: "FIFA F24. Ligue européenne",
    fifa_version: "FIFA FC 24",
    format: "11x11",
    region: "Europe"
  },
  {
    id: 4,
    name: "FIFA FC 24.Championnat d'Allemagne",
    fifa_version: "FIFA FC 24",
    format: "11x11", 
    region: "Allemagne"
  },
  {
    id: 5,
    name: "FIFA FC 24.Championnat d'Espagne",
    fifa_version: "FIFA FC 24",
    format: "11x11",
    region: "Espagne"
  },
  {
    id: 6,
    name: "FIFA FC 25.3x3 ligue de conférence",
    fifa_version: "FIFA FC 25",
    format: "3x3",
    region: "International"
  },
  {
    id: 7,
    name: "FIFA FC 25. Champion league",
    fifa_version: "FIFA FC 25",
    format: "11x11",
    region: "Europe"
  }
]

export const mockMatches = [
  {
    id: 1,
    home_team: { id: 1, name: "Manchester United FC", league_id: 1 },
    away_team: { id: 2, name: "Arsenal FC", league_id: 1 },
    league: { id: 1, name: "FIFA FC 24. 4x4 Championnat d'Angleterre" },
    match_date: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString() // Dans 2 heures
  },
  {
    id: 2,
    home_team: { id: 3, name: "Barcelona Digital", league_id: 2 },
    away_team: { id: 4, name: "Real Madrid Virtual", league_id: 2 },
    league: { id: 2, name: "FIFA FC 24.5x5 Super ligue" },
    match_date: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString() // Dans 4 heures
  },
  {
    id: 3,
    home_team: { id: 5, name: "Bayern Munich", league_id: 4 },
    away_team: { id: 6, name: "Borussia Dortmund", league_id: 4 },
    league: { id: 4, name: "FIFA FC 24.Championnat d'Allemagne" },
    match_date: new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString() // Dans 6 heures
  },
  {
    id: 4,
    home_team: { id: 7, name: "Juventus FC", league_id: 3 },
    away_team: { id: 8, name: "AC Milan", league_id: 3 },
    league: { id: 3, name: "FIFA F24. Ligue européenne" },
    match_date: new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString() // Dans 8 heures
  },
  {
    id: 5,
    home_team: { id: 9, name: "PSG Virtual", league_id: 7 },
    away_team: { id: 10, name: "Chelsea Digital", league_id: 7 },
    league: { id: 7, name: "FIFA FC 25. Champion league" },
    match_date: new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString() // Dans 12 heures
  },
  {
    id: 6,
    home_team: { id: 11, name: "Atletico Madrid", league_id: 5 },
    away_team: { id: 12, name: "Valencia CF", league_id: 5 },
    league: { id: 5, name: "FIFA FC 24.Championnat d'Espagne" },
    match_date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // Dans 24 heures
  }
]

export const generateMockPrediction = (matchId) => {
  // Générer des prédictions réalistes aléatoires
  const homeWinProb = 0.2 + Math.random() * 0.5 // Entre 20% et 70%
  const awayWinProb = 0.2 + Math.random() * 0.5 // Entre 20% et 70%
  const drawProb = Math.max(0.1, 1 - homeWinProb - awayWinProb) // Au moins 10%
  
  // Normaliser pour que la somme soit 1
  const total = homeWinProb + drawProb + awayWinProb
  const normalizedHomeWin = homeWinProb / total
  const normalizedDraw = drawProb / total
  const normalizedAwayWin = awayWinProb / total
  
  // Prédictions de buts
  const homeGoalsFirstHalf = Math.random() * 2
  const homeGoalsSecondHalf = Math.random() * 2
  const awayGoalsFirstHalf = Math.random() * 2
  const awayGoalsSecondHalf = Math.random() * 2
  
  // Probabilités mi-temps
  const htHomeProb = 0.2 + Math.random() * 0.4
  const htAwayProb = 0.2 + Math.random() * 0.4
  const htDrawProb = 1 - htHomeProb - htAwayProb
  
  return {
    home_win_prob: normalizedHomeWin,
    draw_prob: normalizedDraw,
    away_win_prob: normalizedAwayWin,
    home_win_ht_prob: htHomeProb,
    draw_ht_prob: htDrawProb,
    away_win_ht_prob: htAwayProb,
    both_teams_score_prob: 0.4 + Math.random() * 0.4, // Entre 40% et 80%
    home_goals_first_half_pred: homeGoalsFirstHalf,
    away_goals_first_half_pred: awayGoalsFirstHalf,
    home_goals_second_half_pred: homeGoalsSecondHalf,
    away_goals_second_half_pred: awayGoalsSecondHalf
  }
}

