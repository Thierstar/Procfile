import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Calendar, Trophy, Target, TrendingUp, Clock, Users } from 'lucide-react'
import { mockLeagues, mockMatches, generateMockPrediction } from './components/MockData.jsx'
import './App.css'

// Configuration de l'API
const API_BASE_URL = 'https://5000-i185dblg3xxiya6kui0tc-dfc5c82f.manusvm.computer/api'
const USE_MOCK_DATA = true // Utiliser les données de démonstration pour la démo

function App() {
  const [leagues, setLeagues] = useState([])
  const [matches, setMatches] = useState([])
  const [selectedLeague, setSelectedLeague] = useState(null)
  const [loading, setLoading] = useState(true)
  const [predictions, setPredictions] = useState({})

  // Charger les données initiales
  useEffect(() => {
    loadLeagues()
    loadMatches()
  }, [])

  const loadLeagues = async () => {
    try {
      if (USE_MOCK_DATA) {
        setLeagues(mockLeagues)
        return
      }
      
      const response = await fetch(`${API_BASE_URL}/leagues`)
      const data = await response.json()
      setLeagues(data)
    } catch (error) {
      console.error('Erreur lors du chargement des ligues:', error)
      // Fallback vers les données mock en cas d'erreur
      setLeagues(mockLeagues)
    }
  }

  const loadMatches = async () => {
    try {
      setLoading(true)
      
      if (USE_MOCK_DATA) {
        let filteredMatches = mockMatches
        if (selectedLeague) {
          filteredMatches = mockMatches.filter(match => match.league.id === selectedLeague)
        }
        setMatches(filteredMatches)
        setLoading(false)
        return
      }
      
      const url = selectedLeague 
        ? `${API_BASE_URL}/matches?league_id=${selectedLeague}`
        : `${API_BASE_URL}/matches`
      
      const response = await fetch(url)
      const data = await response.json()
      setMatches(data)
    } catch (error) {
      console.error('Erreur lors du chargement des matchs:', error)
      // Fallback vers les données mock en cas d'erreur
      let filteredMatches = mockMatches
      if (selectedLeague) {
        filteredMatches = mockMatches.filter(match => match.league.id === selectedLeague)
      }
      setMatches(filteredMatches)
    } finally {
      setLoading(false)
    }
  }

  const loadPrediction = async (matchId) => {
    try {
      if (USE_MOCK_DATA) {
        // Simuler un délai de chargement
        setTimeout(() => {
          setPredictions(prev => ({
            ...prev,
            [matchId]: generateMockPrediction(matchId)
          }))
        }, 1000)
        return
      }
      
      const response = await fetch(`${API_BASE_URL}/matches/${matchId}/prediction`)
      const data = await response.json()
      setPredictions(prev => ({
        ...prev,
        [matchId]: data.prediction
      }))
    } catch (error) {
      console.error('Erreur lors du chargement de la prédiction:', error)
      // Fallback vers une prédiction mock
      setPredictions(prev => ({
        ...prev,
        [matchId]: generateMockPrediction(matchId)
      }))
    }
  }

  // Recharger les matchs quand la ligue change
  useEffect(() => {
    loadMatches()
  }, [selectedLeague])

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const formatPercentage = (value) => {
    return `${(value * 100).toFixed(1)}%`
  }

  const getResultPrediction = (prediction) => {
    const probs = [
      { label: 'Victoire Domicile', value: prediction.home_win_prob, color: 'bg-green-500' },
      { label: 'Match Nul', value: prediction.draw_prob, color: 'bg-yellow-500' },
      { label: 'Victoire Extérieur', value: prediction.away_win_prob, color: 'bg-red-500' }
    ]
    return probs.sort((a, b) => b.value - a.value)[0]
  }

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900">
        {/* Header */}
        <header className="bg-black/20 backdrop-blur-sm border-b border-white/10">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Trophy className="h-8 w-8 text-yellow-400" />
                <div>
                  <h1 className="text-2xl font-bold text-white">FIFA Virtual Predictions</h1>
                  <p className="text-sm text-gray-300">Prédictions IA pour 1xbet</p>
                </div>
              </div>
              <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                ID: 274685127
              </Badge>
            </div>
          </div>
        </header>

        <div className="container mx-auto px-4 py-6">
          {/* Filtres */}
          <Card className="mb-6 bg-white/10 backdrop-blur-sm border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Users className="mr-2 h-5 w-5" />
                Ligues FIFA Virtuelles
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={selectedLeague === null ? "default" : "outline"}
                  onClick={() => setSelectedLeague(null)}
                  className="text-sm"
                >
                  Toutes les ligues
                </Button>
                {leagues.map(league => (
                  <Button
                    key={league.id}
                    variant={selectedLeague === league.id ? "default" : "outline"}
                    onClick={() => setSelectedLeague(league.id)}
                    className="text-sm"
                  >
                    {league.name}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Liste des matchs */}
          <div className="space-y-4">
            {loading ? (
              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardContent className="p-6">
                  <div className="text-center text-white">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
                    Chargement des matchs...
                  </div>
                </CardContent>
              </Card>
            ) : matches.length === 0 ? (
              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardContent className="p-6">
                  <div className="text-center text-white">
                    <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                    <p>Aucun match disponible pour le moment</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              matches.map(match => (
                <MatchCard
                  key={match.id}
                  match={match}
                  prediction={predictions[match.id]}
                  onLoadPrediction={() => loadPrediction(match.id)}
                  formatDate={formatDate}
                  formatPercentage={formatPercentage}
                  getResultPrediction={getResultPrediction}
                />
              ))
            )}
          </div>
        </div>
      </div>
    </Router>
  )
}

// Composant pour afficher un match
function MatchCard({ match, prediction, onLoadPrediction, formatDate, formatPercentage, getResultPrediction }) {
  const [showDetails, setShowDetails] = useState(false)

  const handleShowPrediction = () => {
    if (!prediction) {
      onLoadPrediction()
    }
    setShowDetails(!showDetails)
  }

  return (
    <Card className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/15 transition-all">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Clock className="h-4 w-4 text-gray-300" />
            <span className="text-sm text-gray-300">{formatDate(match.match_date)}</span>
            <Badge variant="outline" className="text-xs border-white/30 text-white">
              {match.league?.name || 'Ligue inconnue'}
            </Badge>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="text-center flex-1">
            <p className="text-white font-semibold">{match.home_team?.name || 'Équipe domicile'}</p>
            <p className="text-xs text-gray-400">Domicile</p>
          </div>
          
          <div className="text-center px-4">
            <p className="text-2xl font-bold text-white">VS</p>
          </div>
          
          <div className="text-center flex-1">
            <p className="text-white font-semibold">{match.away_team?.name || 'Équipe extérieur'}</p>
            <p className="text-xs text-gray-400">Extérieur</p>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <div className="space-y-4">
          <Button 
            onClick={handleShowPrediction}
            className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-semibold"
          >
            <Target className="mr-2 h-4 w-4" />
            {showDetails ? 'Masquer les prédictions' : 'Voir les prédictions'}
          </Button>

          {showDetails && (
            <div className="space-y-4">
              {prediction ? (
                <Tabs defaultValue="result" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 bg-white/10">
                    <TabsTrigger value="result" className="text-white data-[state=active]:bg-white/20">Résultat</TabsTrigger>
                    <TabsTrigger value="goals" className="text-white data-[state=active]:bg-white/20">Buts</TabsTrigger>
                    <TabsTrigger value="stats" className="text-white data-[state=active]:bg-white/20">Stats</TabsTrigger>
                  </TabsList>

                  <TabsContent value="result" className="space-y-3">
                    <div className="grid grid-cols-3 gap-2">
                      <div className="text-center p-3 bg-green-500/20 rounded-lg border border-green-500/30">
                        <p className="text-green-300 text-xs font-medium">Victoire Domicile</p>
                        <p className="text-white font-bold">{formatPercentage(prediction.home_win_prob)}</p>
                      </div>
                      <div className="text-center p-3 bg-yellow-500/20 rounded-lg border border-yellow-500/30">
                        <p className="text-yellow-300 text-xs font-medium">Match Nul</p>
                        <p className="text-white font-bold">{formatPercentage(prediction.draw_prob)}</p>
                      </div>
                      <div className="text-center p-3 bg-red-500/20 rounded-lg border border-red-500/30">
                        <p className="text-red-300 text-xs font-medium">Victoire Extérieur</p>
                        <p className="text-white font-bold">{formatPercentage(prediction.away_win_prob)}</p>
                      </div>
                    </div>

                    <div className="p-3 bg-blue-500/20 rounded-lg border border-blue-500/30">
                      <p className="text-blue-300 text-xs font-medium mb-1">Prédiction principale</p>
                      <p className="text-white font-bold">{getResultPrediction(prediction).label}</p>
                    </div>
                  </TabsContent>

                  <TabsContent value="goals" className="space-y-3">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <p className="text-white font-medium text-sm">Domicile</p>
                        <div className="p-2 bg-white/10 rounded border border-white/20">
                          <p className="text-xs text-gray-300">1ère mi-temps</p>
                          <p className="text-white font-bold">{prediction.home_goals_first_half_pred.toFixed(1)}</p>
                        </div>
                        <div className="p-2 bg-white/10 rounded border border-white/20">
                          <p className="text-xs text-gray-300">2ème mi-temps</p>
                          <p className="text-white font-bold">{prediction.home_goals_second_half_pred.toFixed(1)}</p>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <p className="text-white font-medium text-sm">Extérieur</p>
                        <div className="p-2 bg-white/10 rounded border border-white/20">
                          <p className="text-xs text-gray-300">1ère mi-temps</p>
                          <p className="text-white font-bold">{prediction.away_goals_first_half_pred.toFixed(1)}</p>
                        </div>
                        <div className="p-2 bg-white/10 rounded border border-white/20">
                          <p className="text-xs text-gray-300">2ème mi-temps</p>
                          <p className="text-white font-bold">{prediction.away_goals_second_half_pred.toFixed(1)}</p>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="stats" className="space-y-3">
                    <div className="p-3 bg-purple-500/20 rounded-lg border border-purple-500/30">
                      <p className="text-purple-300 text-xs font-medium mb-1">Les deux équipes marquent</p>
                      <p className="text-white font-bold">{formatPercentage(prediction.both_teams_score_prob)}</p>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div className="text-center p-2 bg-white/10 rounded">
                        <p className="text-gray-300">1ère MT Domicile</p>
                        <p className="text-white font-bold">{formatPercentage(prediction.home_win_ht_prob)}</p>
                      </div>
                      <div className="text-center p-2 bg-white/10 rounded">
                        <p className="text-gray-300">1ère MT Nul</p>
                        <p className="text-white font-bold">{formatPercentage(prediction.draw_ht_prob)}</p>
                      </div>
                      <div className="text-center p-2 bg-white/10 rounded">
                        <p className="text-gray-300">1ère MT Extérieur</p>
                        <p className="text-white font-bold">{formatPercentage(prediction.away_win_ht_prob)}</p>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              ) : (
                <div className="text-center py-4">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white mx-auto mb-2"></div>
                  <p className="text-white text-sm">Génération de la prédiction...</p>
                </div>
              )}

              <Button 
                variant="outline" 
                className="w-full border-yellow-500/50 text-yellow-300 hover:bg-yellow-500/10"
                onClick={() => window.open('https://1xbet.com', '_blank')}
              >
                <TrendingUp className="mr-2 h-4 w-4" />
                Parier sur 1xbet
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

export default App

